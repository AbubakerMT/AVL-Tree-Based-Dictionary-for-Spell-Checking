import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Dictionary{
    private AVLTree<String> dict;
    public Dictionary(String s){
        dict = new AVLTree<>();
        dict.insertAVL(s.toLowerCase());
    }
    public Dictionary(){
        dict = new AVLTree<>();
    }
    public Dictionary(File f){
        try {
            dict = new AVLTree<>();
            Scanner input = new Scanner(f);
            while(input.hasNext()) {
                String word = input.next().toLowerCase().strip();
                if(!dict.isInTree(word))
                    dict.insertAVL(word);
            }
            input.close();
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    public void display(){
        dict.inorder();
        System.out.println();
    }
    

    public void addWord(String s) throws WordAlreadyExistsException{
        if(!this.dict.isInTree(s.toLowerCase())) {
            this.dict.insertAVL(s.toLowerCase());
            System.out.println("Word '" + s + "' added successfully.");
        }
        else throw new WordAlreadyExistsException("Word '" + s + "' already exists.");
    }

	public void deleteWord(String s) throws WordNotFoundException{
        if(this.dict.isInTree(s.toLowerCase())) {
            this.dict.deleteAVL(s.toLowerCase());
            System.out.println("Word '" + s + "' deleted successfully.");
        }
        else throw new WordNotFoundException("Word '" + s + "' not found.");
    }
    
    public boolean findWord(String s){return this.dict.isInTree(s.toLowerCase());}

    

    private boolean isSimilar(String searched, String compared) {
        searched = searched.toLowerCase();
        compared = compared.toLowerCase();
        int i = 0;
        int j = 0;
        boolean flag = false;
        
        if(searched.length() - compared.length() > 1 || searched.length() - compared.length() < -1) return false;
        if(searched.compareTo(compared) == 0) return false;

        while (i < searched.length() && j < compared.length()) {
            if (searched.charAt(i) == compared.charAt(j)) {
                i++;
                j++;
            } 
            else if (!flag) {
                flag = true;
                if (searched.length() > compared.length()) i++;
                else if (searched.length() < compared.length()) j++;
                else {
                    i++;
                    j++;
                }
            } 
            else {
                return false;
            }
        }
    
        return true;
    }

    public String findSimilar(String s) {
        String result = findSimilar(this.dict.root, s);
        if(result.isEmpty()) return "There is no word similar to " + s + ".";
        else return result.substring(0, result.length()-2) + ".";
    }

    private String findSimilar(BSTNode<String> root, String word) {
        if(root == null) return"";
        return isSimilar(word, root.el) ? root.el + ", " + findSimilar(root.right, word) + findSimilar(root.left, word) : findSimilar(root.right, word) + findSimilar(root.left, word);
    }

    public void save(String name){
        File file = new File(name);
        try{
        PrintWriter output = new PrintWriter(file);
        writer(this.dict.root, output);
        output.close();
        }catch(Exception e){System.out.println(e.getMessage());}
        
    }

    private void writer(BSTNode<String> root, PrintWriter output){
        if(root == null) return;
        output.println(root.el);
        writer(root.left, output);
        writer(root.right, output);
    }
}